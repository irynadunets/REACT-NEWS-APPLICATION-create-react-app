import React from 'react'
import PropTypes from 'prop-types'

class Add extends React.Component {
  state = {
    name: '',
    text: '',
    bigText: '', // добавлен bigText
    agree: false,
  }
  onBtnClickHandler = (e) => {
    e.preventDefault()
    const { name, text, bigText } = this.state
    this.props.onAddNews({
      id: +new Date(),
      author: name,
      text,
      bigText,
    })
  }
  handleChange = (e) => {
    const { id, value } = e.currentTarget
    this.setState({ [id]: value })
  }
  handleCheckboxChange = (e) => {
    this.setState({ agree: e.currentTarget.checked })
  }
  validate = () => {
    const { name, text, agree } = this.state
    if (name.trim() && text.trim() && agree) {
      return true
    }
    return false
  }
  render() {
    const { name, text, bigText } = this.state
    return (
      <form className='add'>
        <input
          id='name'
          type='text'
          onChange={this.handleChange}
          className='add__author'
          placeholder='Your name'
          value={name}
        />
        <textarea
          id='text'
          onChange={this.handleChange}
          className='add__text'
          placeholder='New text'
          value={text}
        ></textarea>
        {/* добавили bigText */}
        <textarea
          id='bigText'
          onChange={this.handleChange}
          className='add__text'
          placeholder='Text news more'
          value={bigText}
        ></textarea>
        <label className='add__checkrule'>
          <input type='checkbox' onChange={this.handleCheckboxChange} /> I agree
        </label>
        <button
          className='add__btn'
          onClick={this.onBtnClickHandler}
          disabled={!this.validate()}>
          Add new
        </button>
      </form>
    )
  }
}

Add.propTypes = {
  onAddNews: PropTypes.func.isRequired,
}
export { Add }
